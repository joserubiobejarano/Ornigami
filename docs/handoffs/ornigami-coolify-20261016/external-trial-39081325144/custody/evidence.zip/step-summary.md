# Ornigami diagnostic evidence

Run 39081325144 / attempt 1; request ee9232408d6e95758b9fb89633c829cf06f5cb69.
### Build request admission
- Request commit: `ee9232408d6e95758b9fb89633c829cf06f5cb69`
- Commit: `7e73ed6f29e7341382c6781c4565d23a2f016fa7`
- Committed package-lock.json SHA-256: `4591e2dd1a858104f9a388dcbe5ccf5d50383b847553e13117061c646238e815`
- Detached checkout package-lock.json SHA-256: `4591e2dd1a858104f9a388dcbe5ccf5d50383b847553e13117061c646238e815`
- Request marker: exact source and lock fields; only marker changed in single-parent request commit
- Workflow blob: identical at candidate and request commits
- Candidate is an ancestor of the request commit
- Checkout: detached exact candidate; clean before build
### Runner preflight
- Online CPUs: 4 (minimum 4)
- Total memory: 15989 MiB (minimum 14336 MiB)
- Available memory before build: 14573 MiB (minimum 12288 MiB)
- Free runner disk before build: 91797909504 bytes (minimum 21474836480)
### Scanner verification
- Trivy 0.76.0 Linux amd64 archive checksum verified against the official release checksum file:
  https://github.com/aquasecurity/trivy/releases/download/v0.76.0/trivy_0.76.0_checksums.txt

Original minimal runtime base: CRITICAL=0 HIGH=0; both parents and tooling scans retained; strict aggregate gate remains independent.
Base scan gate: CRITICAL=0 HIGH=0 (threshold: zero for both)
