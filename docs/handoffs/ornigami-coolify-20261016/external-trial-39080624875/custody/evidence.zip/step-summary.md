# Ornigami diagnostic evidence

Run 39080624875 / attempt 1; request 88fb66569c8b68c7fa60a98ccac49e6cb97b860e.
### Build request admission
- Request commit: `88fb66569c8b68c7fa60a98ccac49e6cb97b860e`
- Commit: `7b8b9011e038009d9d3b9aa3259f474bc6ca47cf`
- Committed package-lock.json SHA-256: `4591e2dd1a858104f9a388dcbe5ccf5d50383b847553e13117061c646238e815`
- Detached checkout package-lock.json SHA-256: `4591e2dd1a858104f9a388dcbe5ccf5d50383b847553e13117061c646238e815`
- Request marker: exact source and lock fields; only marker changed in single-parent request commit
- Workflow blob: identical at candidate and request commits
- Candidate is an ancestor of the request commit
- Checkout: detached exact candidate; clean before build
### Runner preflight
- Online CPUs: 4 (minimum 4)
- Total memory: 15988 MiB (minimum 14336 MiB)
- Available memory before build: 14400 MiB (minimum 12288 MiB)
- Free runner disk before build: 91803680768 bytes (minimum 21474836480)
### Scanner verification
- Trivy 0.76.0 Linux amd64 archive checksum verified against the official release checksum file:
  https://github.com/aquasecurity/trivy/releases/download/v0.76.0/trivy_0.76.0_checksums.txt
