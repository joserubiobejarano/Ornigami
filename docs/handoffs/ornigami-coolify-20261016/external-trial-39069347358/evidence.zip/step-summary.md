# Ornigami diagnostic evidence

Run 39069347358 / attempt 1; request bc4e3b1fcaec11d32187a532611e98e16478d079.
### Build request admission
- Request commit: `bc4e3b1fcaec11d32187a532611e98e16478d079`
- Commit: `f6e26a1fc91826d760acc75c8bfa9612564115d6`
- Committed package-lock.json SHA-256: `4591e2dd1a858104f9a388dcbe5ccf5d50383b847553e13117061c646238e815`
- Detached checkout package-lock.json SHA-256: `4591e2dd1a858104f9a388dcbe5ccf5d50383b847553e13117061c646238e815`
- Request marker: exact source and lock fields; only marker changed in single-parent request commit
- Workflow blob: identical at candidate and request commits
- Candidate is an ancestor of the request commit
- Checkout: detached exact candidate; clean before build
### Runner preflight
- Online CPUs: 4 (minimum 4)
- Total memory: 15989 MiB (minimum 14336 MiB)
- Available memory before build: 14584 MiB (minimum 12288 MiB)
- Free runner disk before build: 91844472832 bytes (minimum 21474836480)
### Scanner verification
- Trivy 0.76.0 Linux amd64 archive checksum verified against the official release checksum file:
  https://github.com/aquasecurity/trivy/releases/download/v0.76.0/trivy_0.76.0_checksums.txt

Original minimal runtime base: CRITICAL=0 HIGH=0; both parents and tooling scans retained; strict aggregate gate remains independent.
### BuildKit cgroup limits
- memory.max: 8589934592 bytes; memory.swap.max: 0 bytes (Docker memory and memory-swap both capped at 8 GiB total)
- cpu.max: 300000 100000; BuildKit OCI worker max-parallelism: 1
- Initial memory event and CPU counters captured before build; no retry is configured

### Build result and cgroup counters

- Build interval: 2026-10-17T21:05:18Z to 2026-10-17T21:07:34Z UTC (136 seconds)
- Build command exit code: 0
- Observed builder counters immediately after build:
```text
==memory.max==
8589934592
==memory.swap.max==
0
==memory.peak==
7756804096
==memory.events==
low 0
high 0
max 0
oom 0
oom_kill 0
oom_group_kill 0
==cpu.max==
300000 100000
==cpu.stat==
usage_usec 174103806
user_usec 143538881
system_usec 30564924
nice_usec 0
core_sched.force_idle_usec 0
nr_periods 1053
nr_throttled 83
throttled_usec 4834638
nr_bursts 0
burst_usec 0
```

### Local image identity

- Image ID: `sha256:a6e55b9b362647219b7d7af4d0d64d2bdfd78c3f814f74433f7eca28e2c0aa76`
- Platform: `linux/amd64`
- Source revision label: `f6e26a1fc91826d760acc75c8bfa9612564115d6`
- Image delivery: local runner only; no image publication
Linux runtime acceptance passed for ornigami:rehearsal-f6e26a1fc91826d760acc75c8bfa9612564115d6. Local image retained; runtime container and cache volume will be removed.
report=/home/runner/work/_temp/ornigami-runtime-acceptance-f6e26a1fc918-64e7c8d0-fb0d-4b42-a0a9-bcefbdaf5ca6/report.txt

### Runtime acceptance receipt

```text
image=ornigami:rehearsal-f6e26a1fc91826d760acc75c8bfa9612564115d6
image_id=sha256:a6e55b9b362647219b7d7af4d0d64d2bdfd78c3f814f74433f7eca28e2c0aa76
image_size_bytes=1702147954
image_platform=linux/amd64
image_user=1000:1000
image_revision=f6e26a1fc91826d760acc75c8bfa9612564115d6
image_origin=https://rehearsal.invalid
started_at_utc=2026-10-17T21:07:35Z
runtime_env=all_features_disabled;no_database_or_provider_secrets;synthetic_google_only
native_image_formats=passed
runtime_uid=1000
runtime_inspect_limits=805306368|805306368|750000000|128|true|none|{}|["ALL"]|["no-new-privileges:true"]
root_write=rejected
tmp_write=allowed
cold_http_exit_status=0
static_csp_hash_count=2
sri_assets_verified=15
hostile_forwarded_redirect_origin=https://rehearsal.invalid
image_cache_body_sha256=af07cc460260bbbee901e61cea55e2b65e2dc8424d0955d36cc7a52a8ac0cafd
next_image_cache_before_restart=[["snmK72j5kLJQ9b3ax2jtD3NYrQFvNZFA08mPmhJzBYE/14400.1792285668227.rwfMRgJgu77pAeYc6lXitl4tyEJNCVXTbMelKorAyv0.Vy8iMzcwLTFhMTRiYWRiZTAwIg.webp",416,"af07cc460260bbbee901e61cea55e2b65e2dc8424d0955d36cc7a52a8ac0cafd"]]
container_id_before_restart=1a392ad7e1c7f77e45dad75b0006cbb69a6c87431fd745eea6d1d15ca5e0fc14
cache_volume=ornigami-runtime-cache-f6e26a1fc918-64e7c8d0-fb0d-4b42-a0a9-bcefbdaf5ca6
cache_mount_before_restart=ornigami-runtime-cache-f6e26a1fc918-64e7c8d0-fb0d-4b42-a0a9-bcefbdaf5ca6
image_id_before_restart=sha256:a6e55b9b362647219b7d7af4d0d64d2bdfd78c3f814f74433f7eca28e2c0aa76
image_cache_restart=hit (HIT)
container_id_after_restart=1a392ad7e1c7f77e45dad75b0006cbb69a6c87431fd745eea6d1d15ca5e0fc14
restart_http=true
next_image_cache_restart=true
runtime_env=all_features_disabled;no_database_or_provider_secrets;synthetic_google_only
image_cache_recreate=hit (HIT)
container_id_after_recreate=99b9c9a185a6912f031852f8571ab36c58733c22e654e5ddc571d6b5fc2e2666
container_identity_check=restart_same_recreate_new
image_identity_check=same_image_id_across_recreate
image_id_after_recreate=sha256:a6e55b9b362647219b7d7af4d0d64d2bdfd78c3f814f74433f7eca28e2c0aa76
cache_volume_identity_check=same_named_volume_across_recreate
cache_mount_after_recreate=ornigami-runtime-cache-f6e26a1fc918-64e7c8d0-fb0d-4b42-a0a9-bcefbdaf5ca6
recreate_http=true
next_image_cache_recreate=true
cache_persistence_scope=next_image_cache_volume_only;does_not_accept_database_or_media_storage
finished_at_utc=2026-10-17T21:08:02Z
runtime_elapsed_seconds=27
result=passed
runtime_cgroup_metrics=runtime-first-cgroup.txt,runtime-after-restart-cgroup.txt,runtime-after-recreate-cgroup.txt
state=running oom_killed=false exit_code=0 memory=805306368 swap=805306368 nanocpus=750000000 pids=128 readonly=true network=none port_bindings={}

==runtime-after-recreate-cgroup.txt==
==memory.max==
805306368
==memory.swap.max==
0
==memory.current==
152539136
==memory.peak==
173772800
==memory.events==
low 0
high 0
max 0
oom 0
oom_kill 0
oom_group_kill 0
==memory.stat==
anon 143028224
file 8192
kernel 8630272
kernel_stack 327680
pagetables 4063232
sec_pagetables 0
percpu 2544
sock 0
vmalloc 24576
shmem 0
zswap 0
zswapped 0
file_mapped 0
file_dirty 8192
file_writeback 0
swapcached 0
anon_thp 25165824
file_thp 0
shmem_thp 0
inactive_anon 0
active_anon 142934016
inactive_file 8192
active_file 4096
unevictable 0
slab_reclaimable 3566184
slab_unreclaimable 625072
slab 4191256
workingset_refault_anon 0
workingset_refault_file 0
workingset_activate_anon 0
workingset_activate_file 0
workingset_restore_anon 0
workingset_restore_file 0
workingset_nodereclaim 0
pgdemote_kswapd 0
pgdemote_direct 0
pgdemote_khugepaged 0
pgdemote_proactive 0
pgpromote_success 0
pgscan 0
pgsteal 0
pswpin 0
pswpout 0
pgscan_kswapd 0
pgscan_direct 0
pgscan_khugepaged 0
pgscan_proactive 0
pgsteal_kswapd 0
pgsteal_direct 0
pgsteal_khugepaged 0
pgsteal_proactive 0
pgfault 107779
pgmajfault 0
pgrefill 0
pgactivate 0
pgdeactivate 0
pglazyfree 0
pglazyfreed 0
swpin_zero 0
swpout_zero 0
zswpin 0
zswpout 0
zswpwb 0
thp_fault_alloc 24
thp_collapse_alloc 0
thp_swpout 0
thp_swpout_fallback 0
numa_pages_migrated 0
numa_pte_updates 0
numa_hint_faults 0
==memory.pressure==
some avg10=0.00 avg60=0.00 avg300=0.00 total=0
full avg10=0.00 avg60=0.00 avg300=0.00 total=0
==cpu.max==
75000 100000
==cpu.stat==
usage_usec 2065881
user_usec 1736010
system_usec 329871
nice_usec 0
core_sched.force_idle_usec 0
nr_periods 31
nr_throttled 24
throttled_usec 1450122
nr_bursts 0
burst_usec 0
==pids.max==
128

==runtime-after-restart-cgroup.txt==
==memory.max==
805306368
==memory.swap.max==
0
==memory.current==
148713472
==memory.peak==
169938944
==memory.events==
low 0
high 0
max 0
oom 0
oom_kill 0
oom_group_kill 0
==memory.stat==
anon 142716928
file 0
kernel 5201920
kernel_stack 327680
pagetables 4096000
sec_pagetables 0
percpu 2544
sock 0
vmalloc 24576
shmem 0
zswap 0
zswapped 0
file_mapped 0
file_dirty 0
file_writeback 0
swapcached 0
anon_thp 23068672
file_thp 0
shmem_thp 0
inactive_anon 0
active_anon 142622720
inactive_file 0
active_file 4096
unevictable 0
slab_reclaimable 104024
slab_unreclaimable 626120
slab 730144
workingset_refault_anon 0
workingset_refault_file 0
workingset_activate_anon 0
workingset_activate_file 0
workingset_restore_anon 0
workingset_restore_file 0
workingset_nodereclaim 0
pgdemote_kswapd 0
pgdemote_direct 0
pgdemote_khugepaged 0
pgdemote_proactive 0
pgpromote_success 0
pgscan 0
pgsteal 0
pswpin 0
pswpout 0
pgscan_kswapd 0
pgscan_direct 0
pgscan_khugepaged 0
pgscan_proactive 0
pgsteal_kswapd 0
pgsteal_direct 0
pgsteal_khugepaged 0
pgsteal_proactive 0
pgfault 105144
pgmajfault 0
pgrefill 0
pgactivate 0
pgdeactivate 0
pglazyfree 0
pglazyfreed 0
swpin_zero 0
swpout_zero 0
zswpin 0
zswpout 0
zswpwb 0
thp_fault_alloc 24
thp_collapse_alloc 0
thp_swpout 0
thp_swpout_fallback 0
numa_pages_migrated 0
numa_pte_updates 0
numa_hint_faults 0
==memory.pressure==
some avg10=0.00 avg60=0.00 avg300=0.00 total=0
full avg10=0.00 avg60=0.00 avg300=0.00 total=0
==cpu.max==
75000 100000
==cpu.stat==
usage_usec 2132749
user_usec 1836286
system_usec 296463
nice_usec 0
core_sched.force_idle_usec 0
nr_periods 31
nr_throttled 25
throttled_usec 1739388
nr_bursts 0
burst_usec 0
==pids.max==
128

==runtime-final-cgroup.txt==
==memory.max==
805306368
==memory.swap.max==
0
==memory.current==
152465408
==memory.peak==
173772800
==memory.events==
low 0
high 0
max 0
oom 0
oom_kill 0
oom_group_kill 0
==memory.stat==
anon 143024128
file 8192
kernel 8626176
kernel_stack 327680
pagetables 4055040
sec_pagetables 0
percpu 2544
sock 0
vmalloc 24576
shmem 0
zswap 0
zswapped 0
file_mapped 0
file_dirty 8192
file_writeback 0
swapcached 0
anon_thp 25165824
file_thp 0
shmem_thp 0
inactive_anon 0
active_anon 143003648
inactive_file 8192
active_file 4096
unevictable 0
slab_reclaimable 3568976
slab_unreclaimable 627752
slab 4196728
workingset_refault_anon 0
workingset_refault_file 0
workingset_activate_anon 0
workingset_activate_file 0
workingset_restore_anon 0
workingset_restore_file 0
workingset_nodereclaim 0
pgdemote_kswapd 0
pgdemote_direct 0
pgdemote_khugepaged 0
pgdemote_proactive 0
pgpromote_success 0
pgscan 0
pgsteal 0
pswpin 0
pswpout 0
pgscan_kswapd 0
pgscan_direct 0
pgscan_khugepaged 0
pgscan_proactive 0
pgsteal_kswapd 0
pgsteal_direct 0
pgsteal_khugepaged 0
pgsteal_proactive 0
pgfault 114953
pgmajfault 0
pgrefill 0
pgactivate 0
pgdeactivate 0
pglazyfree 0
pglazyfreed 0
swpin_zero 0
swpout_zero 0
zswpin 0
zswpout 0
zswpwb 0
thp_fault_alloc 27
thp_collapse_alloc 0
thp_swpout 0
thp_swpout_fallback 0
numa_pages_migrated 0
numa_pte_updates 0
numa_hint_faults 0
==memory.pressure==
some avg10=0.00 avg60=0.00 avg300=0.00 total=0
full avg10=0.00 avg60=0.00 avg300=0.00 total=0
==cpu.max==
75000 100000
==cpu.stat==
usage_usec 2157130
user_usec 1803680
system_usec 353450
nice_usec 0
core_sched.force_idle_usec 0
nr_periods 33
nr_throttled 24
throttled_usec 1450122
nr_bursts 0
burst_usec 0
==pids.max==
128

==runtime-first-cgroup.txt==
==memory.max==
805306368
==memory.swap.max==
0
==memory.current==
166887424
==memory.peak==
183050240
==memory.events==
low 0
high 0
max 0
oom 0
oom_kill 0
oom_group_kill 0
==memory.stat==
anon 156262400
file 12288
kernel 9887744
kernel_stack 376832
pagetables 4423680
sec_pagetables 0
percpu 2544
sock 0
vmalloc 24576
shmem 4096
zswap 0
zswapped 0
file_mapped 0
file_dirty 4096
file_writeback 0
swapcached 0
anon_thp 25165824
file_thp 0
shmem_thp 0
inactive_anon 0
active_anon 156233728
inactive_file 8192
active_file 4096
unevictable 0
slab_reclaimable 4338664
slab_unreclaimable 696072
slab 5034736
workingset_refault_anon 0
workingset_refault_file 0
workingset_activate_anon 0
workingset_activate_file 0
workingset_restore_anon 0
workingset_restore_file 0
workingset_nodereclaim 0
pgdemote_kswapd 0
pgdemote_direct 0
pgdemote_khugepaged 0
pgdemote_proactive 0
pgpromote_success 0
pgscan 0
pgsteal 0
pswpin 0
pswpout 0
pgscan_kswapd 0
pgscan_direct 0
pgscan_khugepaged 0
pgscan_proactive 0
pgsteal_kswapd 0
pgsteal_direct 0
pgsteal_khugepaged 0
pgsteal_proactive 0
pgfault 120787
pgmajfault 0
pgrefill 0
pgactivate 0
pgdeactivate 0
pglazyfree 0
pglazyfreed 0
swpin_zero 0
swpout_zero 0
zswpin 0
zswpout 0
zswpwb 0
thp_fault_alloc 32
thp_collapse_alloc 0
thp_swpout 0
thp_swpout_fallback 0
numa_pages_migrated 0
numa_pte_updates 0
numa_hint_faults 0
==memory.pressure==
some avg10=0.00 avg60=0.00 avg300=0.00 total=0
full avg10=0.00 avg60=0.00 avg300=0.00 total=0
==cpu.max==
75000 100000
==cpu.stat==
usage_usec 2954269
user_usec 2511380
system_usec 442888
nice_usec 0
core_sched.force_idle_usec 0
nr_periods 44
nr_throttled 35
throttled_usec 3061724
nr_bursts 0
burst_usec 0
==pids.max==
128

==runtime-disk.txt==
[{"path":"/","blockSize":"4096","totalBytes":"154894188544","freeBytes":"81101107200","availableBytes":"81084329984"},{"path":"/tmp","blockSize":"4096","totalBytes":"33554432","freeBytes":"33554432","availableBytes":"33554432"},{"path":"/app/.next/cache","blockSize":"4096","totalBytes":"154894188544","freeBytes":"81101107200","availableBytes":"81084329984"}]

==host-disk-before.txt==
Filesystem     1024-blocks     Used Available Capacity Mounted on
/dev/root        151263856 71124620  80122852      48% /
/dev/root        151263856 71124620  80122852      48% /

==host-disk-after.txt==
Filesystem     1024-blocks     Used Available Capacity Mounted on
/dev/root        151263856 72063560  79183912      48% /
/dev/root        151263856 72063560  79183912      48% /
```

### Final image archive identity

- Docker image ID: `sha256:a6e55b9b362647219b7d7af4d0d64d2bdfd78c3f814f74433f7eca28e2c0aa76`
- Docker image bytes: 1702147954
- Root filesystem layer IDs: `["sha256:9486261b5a13f63ca6904b36721527ac8f19df53d300560138d69ae9b4c203de","sha256:621c35e751a51a9a9dc3e80aa0b7fe8be2a93402ea6ccd307d30852cd7776cda","sha256:763a77745f27b86cf26b97887b6842d83720e63b1c48848c0ba9ee54e351d63a","sha256:f0d0eff4c2312a7bd6e21797bdfea5eb35f60e76b555ce2b22794424af2cad36","sha256:275a30dd8ce958b21daa9ad962c6fbc09f98306ee2f486b65c9075dc257b1412","sha256:4d049f83d9cf21d1f5cc0e11deaf36df02790d0e60c1a3829538fb4b61685368","sha256:af5aa97ebe6ce1604747ec1e21af7136ded391bcabe4acef882e718a87c86bcc","sha256:6f1cdceb6a3146f0ccb986521156bef8a422cdbb0863396f7f751f575ba308f4","sha256:bd3cdfae1d3fdd83a2231d608969b38b82349777c2fff9a7c12d54f8ac5c9b38","sha256:4cde6b0bb6f50a5f255eef7b2a42162c661cf776b803225dcac9a659e396bb6b","sha256:ad51d0769d16ba578106a177987dfe3d2e02c1668c852b795b2f6b024068242a","sha256:187cfc6d1e3e8a40a5e64653bcd3239c140807dcf1c09e48021178705a5a6139","sha256:f2392a9484bf6b18f06beaf705b994e31dbb2716c99cf7d03c9c495cd107f364","sha256:8a3b315d45080ecb38e39d42d28e951303c67c2ce7482bcdbbc3b5424be19013","sha256:2cef49adb7d7902c61ecdd385036e3c7fb7c9f0ada96a41901797c77b7daedd7","sha256:c0e409312adc366898967307565f692bb33d43a439d3de48e27d14b742389725","sha256:e4ba966d7f0527dfe0fcb559e4e18d4da42c4e6beae924719255e0dedb554ed0","sha256:1f5d28bd51650f429293f7730ede274b81dc0744aa918bc887133c4ad610258c","sha256:6e18ad80f3d64a8cbbcd1ff2e8a0d5ce7282cf664e816b86183a59d30a618e8a","sha256:c16b2ec4b1493bad1b1de23d659c899e60abb166bda756d02792f0a03ba54a43","sha256:7db505d90756626f425c6c5468eca565c82f589b144ecaa4f411ad9bbf79e614","sha256:d99e6a7fc3457e2fe86160ade531b8036e86ad14e576e5c09d4e94da2e132ff6","sha256:acf55a98e404765c84bbe3d0dbd997f18732b59cf686448cd4b751b0d223092c","sha256:75d9d7e5ec501de25d96626840670af5fdff96e3ec5fb36d9b827faf19495441","sha256:5c6c05c18e0e6e9cb3eaf5408c7638aa0defa54126c3397d4af40d9d7baf8d42","sha256:28b2479fd9462200660dc3351632c7fb966ef03e074a937470cff3838040d674","sha256:8f3668363c5fc542f4331ddf9c731e3fcbff23c06133135f08574a5d17c64767","sha256:60791c4408166e8091956011d301b41f4dfcc7a6630d1d8bc0dc6c289fb8cb82","sha256:93846bbd6adfd804ea65b41ba260ae860dfca3157fe48702ea2938decb2a5b19","sha256:9d3f33b4ddbd5c6cc5f8bf1e76b6ab2af7fb1fe4231760d8becafe42101a93ab","sha256:bc9535372b775731ea21b72d2c45f53b6b3267b5f844b79163ffb5b394ca6a0c","sha256:37b05c9eed138cca988b165be0771e2cd3d00ca635d397ae3e2c00cb7d0b7b0c","sha256:2fcf226b4ea4a6c4048548b5ab7dda6086008efea75c3d6160436e82debdc324","sha256:f394d2145ab11eb441c9f0ac9f573e455458a3c20c45894fb555d43bf47c349c","sha256:10511e0c26e82a88a28044f7078148c12c9b5fbd0731b4183b202ab8fdfc8b5c","sha256:7689d23fd4e3526a3770d5bcde1d6aea1f5148203486d812ec228043b8c888f2","sha256:31e211ebaea01c3881101dba129e5044469ed164b174dca4b49bdc2da99b4f4c"]`
- Root filesystem layer-list SHA-256: `31d205c87ba44342c8233042751bb24d1eb15c97fcd1af502eeba821023a0793`
- Saved archive SHA-256: `66c78d99832f5348be6795730c0c9598d6ca045556d875bffe0cbb71d9c65576`
- Saved archive bytes: 1735108096
- Trivy report ImageID must match the local Docker image ID above

### Trivy 0.76.0 image scan

| Severity | Findings |
| --- | ---: |
| CRITICAL | 0 |
| HIGH | 0 |
| MEDIUM | 23 |
| LOW | 8 |
| UNKNOWN | 0 |

No image was pushed or published by this workflow.

| Severity | Package | Installed | Fixed | Advisory | Primary URL |
| --- | --- | --- | --- | --- | --- |
| LOW | libc6 | 2.41-12+deb13u4 |  | CVE-2010-4756 | https://avd.aquasec.com/nvd/cve-2010-4756 |
| LOW | libc6 | 2.41-12+deb13u4 |  | CVE-2018-20796 | https://avd.aquasec.com/nvd/cve-2018-20796 |
| LOW | libc6 | 2.41-12+deb13u4 |  | CVE-2019-1010022 | https://avd.aquasec.com/nvd/cve-2019-1010022 |
| LOW | libc6 | 2.41-12+deb13u4 |  | CVE-2019-1010023 | https://avd.aquasec.com/nvd/cve-2019-1010023 |
| LOW | libc6 | 2.41-12+deb13u4 |  | CVE-2019-1010024 | https://avd.aquasec.com/nvd/cve-2019-1010024 |
| LOW | libc6 | 2.41-12+deb13u4 |  | CVE-2019-1010025 | https://avd.aquasec.com/nvd/cve-2019-1010025 |
| LOW | libc6 | 2.41-12+deb13u4 |  | CVE-2019-9192 | https://avd.aquasec.com/nvd/cve-2019-9192 |
| LOW | libc6 | 2.41-12+deb13u4 |  | CVE-2026-97399 | https://avd.aquasec.com/nvd/cve-2026-97399 |
| MEDIUM | gcc-14-base | 14.2.0-19 |  | CVE-2026-102010 | https://avd.aquasec.com/nvd/cve-2026-102010 |
| MEDIUM | gcc-14-base | 14.2.0-19 |  | CVE-2026-95619 | https://avd.aquasec.com/nvd/cve-2026-95619 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-18374 | https://avd.aquasec.com/nvd/cve-2026-18374 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-19499 | https://avd.aquasec.com/nvd/cve-2026-19499 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-19542 | https://avd.aquasec.com/nvd/cve-2026-19542 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-5435 | https://avd.aquasec.com/nvd/cve-2026-5435 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-6238 | https://avd.aquasec.com/nvd/cve-2026-6238 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-6368 | https://avd.aquasec.com/nvd/cve-2026-6368 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-6791 | https://avd.aquasec.com/nvd/cve-2026-6791 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-77117 | https://avd.aquasec.com/nvd/cve-2026-77117 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-80489 | https://avd.aquasec.com/nvd/cve-2026-80489 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-8674 | https://avd.aquasec.com/nvd/cve-2026-8674 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-86805 | https://avd.aquasec.com/nvd/cve-2026-86805 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-89092 | https://avd.aquasec.com/nvd/cve-2026-89092 |
| MEDIUM | libc6 | 2.41-12+deb13u4 |  | CVE-2026-95818 | https://avd.aquasec.com/nvd/cve-2026-95818 |
| MEDIUM | libgcc-s1 | 14.2.0-19 |  | CVE-2026-102010 | https://avd.aquasec.com/nvd/cve-2026-102010 |
| MEDIUM | libgcc-s1 | 14.2.0-19 |  | CVE-2026-95619 | https://avd.aquasec.com/nvd/cve-2026-95619 |
| MEDIUM | libgomp1 | 14.2.0-19 |  | CVE-2026-102010 | https://avd.aquasec.com/nvd/cve-2026-102010 |
| MEDIUM | libgomp1 | 14.2.0-19 |  | CVE-2026-95619 | https://avd.aquasec.com/nvd/cve-2026-95619 |
| MEDIUM | libstdc++6 | 14.2.0-19 |  | CVE-2026-102010 | https://avd.aquasec.com/nvd/cve-2026-102010 |
| MEDIUM | libstdc++6 | 14.2.0-19 |  | CVE-2026-95619 | https://avd.aquasec.com/nvd/cve-2026-95619 |
| MEDIUM | zlib1g | 1:1.3.dfsg+really1.3.1-1+b1 |  | CVE-2026-27171 | https://avd.aquasec.com/nvd/cve-2026-27171 |
| MEDIUM | zlib1g | 1:1.3.dfsg+really1.3.1-1+b1 |  | CVE-2026-85091 | https://avd.aquasec.com/nvd/cve-2026-85091 |

### Build resource acceptance

- Builder memory.peak: 7756804096 bytes
- Build-time memory.events deltas: `{'high': 0, 'low': 0, 'max': 0, 'oom': 0, 'oom_group_kill': 0, 'oom_kill': 0}`
- Build-time cpu.stat deltas: `{'burst_usec': 0, 'core_sched.force_idle_usec': 0, 'nice_usec': 0, 'nr_bursts': 0, 'nr_periods': 1048, 'nr_throttled': 83, 'system_usec': 30509060, 'throttled_usec': 4834638, 'usage_usec': 173937247, 'user_usec': 143428187}`
Base scan gate: CRITICAL=0 HIGH=0 (threshold: zero for both)
