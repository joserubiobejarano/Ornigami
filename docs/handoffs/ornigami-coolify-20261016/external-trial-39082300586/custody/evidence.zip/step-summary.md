# Ornigami diagnostic evidence

Run 39082300586 / attempt 1; request 7c03441e0872e0417762ea96d3b60a97be98a413.
### Build request admission
- Request commit: `7c03441e0872e0417762ea96d3b60a97be98a413`
- Commit: `65ccca1d534f5951120b5ddfe9d04b9288745d7e`
- Committed package-lock.json SHA-256: `4591e2dd1a858104f9a388dcbe5ccf5d50383b847553e13117061c646238e815`
- Detached checkout package-lock.json SHA-256: `4591e2dd1a858104f9a388dcbe5ccf5d50383b847553e13117061c646238e815`
- Request marker: exact source and lock fields; only marker changed in single-parent request commit
- Workflow blob: identical at candidate and request commits
- Candidate is an ancestor of the request commit
- Checkout: detached exact candidate; clean before build
### Runner preflight
- Online CPUs: 4 (minimum 4)
- Total memory: 15989 MiB (minimum 14336 MiB)
- Available memory before build: 14590 MiB (minimum 12288 MiB)
- Free runner disk before build: 91790528512 bytes (minimum 21474836480)
### Scanner verification
- Trivy 0.76.0 Linux amd64 archive checksum verified against the official release checksum file:
  https://github.com/aquasecurity/trivy/releases/download/v0.76.0/trivy_0.76.0_checksums.txt

Original minimal runtime base: CRITICAL=0 HIGH=0; both parents and tooling scans retained; strict aggregate gate remains independent.
### BuildKit cgroup limits
- memory.max: 8589934592 bytes; memory.swap.max: 0 bytes (Docker memory and memory-swap both capped at 8 GiB total)
- cpu.max: 300000 100000; BuildKit OCI worker max-parallelism: 1
- Initial memory event and CPU counters captured before build; no retry is configured

Tooling-only compatibility passed. Application phases intentionally unrequested; advisory coverage and overall security acceptance remain held.
Base scan gate: CRITICAL=0 HIGH=0 (threshold: zero for both)
