Campaign Lab local export

Revision: 857e1840864dd44f
Offer: Cup + lid, €24 · offer ends 30 November 2026
Destination: https://rose.example/products/rose
Approval scope: local-preview
Preview status: confirmed

Open index.html directly in a browser. No server or build step is required. Optional enhancements use only the bundled owned runtime; primary content remains usable without JavaScript.

This is a local preview artifact, not publication approval. Editor controls, internal source notes and campaign-brief data are intentionally excluded.

Bundled fonts retain their matching copyright and license text in fonts/NOTICE.txt and the referenced license files.
